USE login;

CREATE TABLE usuarios(
idUsuario INT NOT NULL,
nombreUsuario varchar(30) not null,
passwordUsuario varchar(30) not null,
nombreRealUsuario varchar(50) not null,
tipoUsuario varchar(50) not null,
PRIMARY KEY (idUsuario)
);

INSERT INTO usuarios (idUsuario, nombreUsuario, passwordUsuario, nombreRealUsuario, tipoUsuario) VALUES (1,'jtapia','123','Juanito Tapia Jiménez','administrador');
INSERT INTO usuarios (idUsuario, nombreUsuario, passwordUsuario, nombreRealUsuario, tipoUsuario) VALUES (2,'jperez','123','Julio Pérez González','usuario normal');
INSERT INTO usuarios (idUsuario, nombreUsuario, passwordUsuario, nombreRealUsuario, tipoUsuario) VALUES (3,'jflores','123','José Flores Espina','super usuario');
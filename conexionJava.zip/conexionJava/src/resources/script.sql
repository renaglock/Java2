CREATE DATABASE uct;

USE uct;

CREATE TABLE Alumnos (
rut varchar(20) not null primary key,
dv  varchar (5) not null,
nombres varchar (50),
apellidos varchar (50),
edad int (5),
ciudad varchar (50),
sexo varchar (20)
);
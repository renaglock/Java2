package model;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {

    String bd = "uct";
    String usuario = "root";
    String clave = "";
    String puerto = "3306";
    String url = "jdbc:mysql://localhost:" + puerto + "/" + bd;

    Connection conectar = null;

    public Connection establecerConexion() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conectar = DriverManager.getConnection(url, usuario, clave);
            System.out.println("Conectado correctamente a " + getBd());
        } catch (Exception mensajeError) {
            System.out.println("Error al conectar" + mensajeError);
        }
        return conectar;
    }
    
    public void desconectar() {
        try {
            if(conectar != null){
                conectar.close();
                System.out.println("Desconectado");
            }
        } catch (Exception e) {
        }
    }

    public String getBd() {
        return bd;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getClave() {
        return clave;
    }

    public String getPuerto() {
        return puerto;
    }

    public String getUrl() {
        return url;
    }

    public Connection getConectar() {
        return conectar;
    }

    public void setBd(String bd) {
        this.bd = bd;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public void setPuerto(String puerto) {
        this.puerto = puerto;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setConectar(Connection conectar) {
        this.conectar = conectar;
    }

}
